@extends('layouts.app')
@section('title', 'Buyer Dashboard')

@section('content')
<div class="container mt-4">
    <h2>Welcome, {{ Auth::user()->name }}</h2>
    <div class="row mt-4">
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h4>{{ $ordersCount }}</h4>
                    <p>Orders</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-center">
                <div class="card-body">
                    <h4>RWF {{ number_format($totalSpent) }}</h4>
                    <p>Total Spent</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
