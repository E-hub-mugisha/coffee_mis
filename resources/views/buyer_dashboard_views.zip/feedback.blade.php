@extends('layouts.app')
@section('title', 'Feedback')

@section('content')
<div class="container mt-4">
    <h4>Submit Feedback</h4>
    <form action="{{ route('buyer.feedback.submit') }}" method="POST">
        @csrf
        <div class="form-group">
            <label>Feedback</label>
            <textarea name="message" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Send</button>
    </form>
</div>
@endsection
